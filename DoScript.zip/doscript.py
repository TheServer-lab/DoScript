import os
import time
import subprocess
import sys
import shutil
import urllib.request
import tempfile
import glob
import platform
import argparse


class DoScriptRuntime:
    def __init__(self):
        self.variables = {}
        self.tasks = {}
        self.dry_run = False
        self.force = False

    # -------------------------
    # Helpers
    # -------------------------
    def _extract_quoted(self, s):
        parts = []
        i = 0
        while i < len(s):
            if s[i] == '"':
                j = i + 1
                while j < len(s) and s[j] != '"':
                    j += 1
                parts.append(s[i+1:j])
                i = j + 1
            else:
                i += 1
        return parts

    def _strip_force(self, line):
        # Remove a standalone --force token if present. Returns (new_line, force_flag)
        tokens = line.split()
        if "--force" in tokens:
            tokens = [t for t in tokens if t != "--force"]
            return " ".join(tokens), True
        return line, False

    def _should_execute(self, description, local_force=False):
        """Determine whether a destructive action should run.
        Returns True if the action should be performed. If dry-run is on, prints the action and returns False.
        """
        # command-line or script variable based dry_run/force
        if self.dry_run or self.variables.get('dry_run', False):
            print(f"[DRY RUN] Would: {description}")
            return False
        if local_force or self.force or self.variables.get('force', False):
            return True
        # ask the user
        try:
            ans = input(f"Confirm: {description}? (y/N): ").strip().lower()
            return ans in ('y', 'yes')
        except Exception:
            # if input not possible, fallback to not executing
            print("No interactive input available; skipping action.")
            return False

    def resolve_value(self, token):
        token = token.strip()
        if token.startswith('"') and token.endswith('"'):
            return token[1:-1]
        if token.lower() == 'true':
            return True
        if token.lower() == 'false':
            return False
        try:
            return int(token)
        except Exception:
            pass
        if token in self.variables:
            return self.variables[token]
        raise RuntimeError(f"Unknown value or variable: {token}")

    def get_indent_level(self, line):
        return len(line) - len(line.lstrip(" "))

    def clear_screen(self):
        if platform.system() == 'Windows':
            os.system('cls')
        else:
            os.system('clear')

    def copy_pattern(self, pattern, dst):
        files = glob.glob(pattern)
        if not files:
            raise RuntimeError(f"No files match pattern: {pattern}")
        os.makedirs(dst, exist_ok=True)
        for f in files:
            if os.path.isfile(f):
                shutil.copy2(f, os.path.join(dst, os.path.basename(f)))

    def xcopy(self, src, dst, recursive=True):
        if os.path.isdir(src):
            if recursive:
                if os.path.exists(dst):
                    # copy contents into dst
                    for root, dirs, files in os.walk(src):
                        rel = os.path.relpath(root, src)
                        target_dir = os.path.join(dst, rel) if rel != '.' else dst
                        os.makedirs(target_dir, exist_ok=True)
                        for file in files:
                            shutil.copy2(os.path.join(root, file), os.path.join(target_dir, file))
                else:
                    shutil.copytree(src, dst)
            else:
                # copy top-level files
                os.makedirs(dst, exist_ok=True)
                for item in os.listdir(src):
                    s = os.path.join(src, item)
                    if os.path.isfile(s):
                        shutil.copy2(s, os.path.join(dst, item))
        elif os.path.isfile(src):
            parent = os.path.dirname(dst)
            if parent:
                os.makedirs(parent, exist_ok=True)
            shutil.copy2(src, dst)
        else:
            raise RuntimeError(f"Source not found: {src}")

    def delete_pattern(self, pattern, force=False):
        files = glob.glob(pattern)
        if not files and not force:
            raise RuntimeError(f"No files match pattern: {pattern}")
        for f in files:
            if os.path.isfile(f):
                os.remove(f)

    def delete_folder_recursive(self, path):
        if os.path.exists(path):
            shutil.rmtree(path)

    def start_program(self, cmd):
        subprocess.Popen(cmd, shell=True)

    def ping_host(self, host, count=1):
        system = platform.system()
        if system == 'Windows':
            cmd = ['ping', '-n', str(count), host]
        else:
            cmd = ['ping', '-c', str(count), host]
        return subprocess.call(cmd) == 0

    def set_env_persist(self, name, value):
        system = platform.system()
        if system == 'Windows':
            # use setx for user environment variables
            subprocess.run(['setx', name, str(value)], check=True)
        else:
            # append to ~/.profile for simplicity
            home = os.path.expanduser('~')
            profile = os.path.join(home, '.profile')
            # ensure proper newline and safe one-line f-string
            entry = f'export {name}="{value}"\\n'
            with open(profile, 'a', encoding='utf-8') as f:
                f.write(entry)

    # -------------------------
    # Core execution
    # -------------------------
    def run_file(self, path):
        with open(path, "r", encoding="utf-8") as f:
            lines = f.readlines()
        self.execute_block(lines, 0, 0, path)

    def execute_block(self, lines, start_index, base_indent, filename):
        i = start_index
        while i < len(lines):
            raw_line = lines[i].rstrip("\n")
            if not raw_line.strip() or raw_line.strip().startswith("#"):
                i += 1
                continue
            indent = self.get_indent_level(raw_line)
            if indent < base_indent:
                return i
            # strip force token early
            original_line = raw_line.strip()
            line, local_force = self._strip_force(original_line)
            lineno = i + 1
            if self.variables.get('debug', False):
                print(f"[DEBUG] {filename}:{lineno}: {line}")
            try:
                # echo / batch
                if line.startswith("echo "):
                    val = self.resolve_value(line[5:])
                    print(val)

                elif line == "pause":
                    input("Press any key to continue...")

                elif line == "cls":
                    self.clear_screen()

                # set persistent env
                elif line.startswith("set_env_persist ") and " to " in line:
                    parts = line.split(" to ")
                    left = parts[0][len("set_env_persist "):].strip()
                    name = self.resolve_value(left)
                    value = self.resolve_value(parts[1])
                    desc = f"set persistent environment variable {name}={value}"
                    if self._should_execute(desc, local_force):
                        self.set_env_persist(name, value)

                # set in-process env
                elif line.startswith("set_env ") and " to " in line:
                    parts = line.split(" to ")
                    left = parts[0][len("set_env "):].strip()
                    name = self.resolve_value(left)
                    value = self.resolve_value(parts[1])
                    os.environ[name] = str(value)

                elif line.startswith("get_env "):
                    name = self.resolve_value(line[len("get_env "):])
                    print(os.environ.get(name, ""))

                elif line.startswith("say "):
                    value = self.resolve_value(line[4:])
                    print(value)

                elif line.startswith("set ") and " to " in line:
                    _, rest = line.split("set ", 1)
                    name, value = rest.split(" to ", 1)
                    self.variables[name.strip()] = self.resolve_value(value)

                # arithmetic
                elif line.startswith("add ") and " to " in line:
                    num, var = line[4:].split(" to ")
                    self.variables[var.strip()] = int(self.resolve_value(num)) + int(self.variables.get(var.strip(), 0))

                elif line.startswith("subtract ") and " from " in line:
                    num, var = line[9:].split(" from ")
                    self.variables[var.strip()] = int(self.variables.get(var.strip(), 0)) - int(self.resolve_value(num))

                elif line.startswith("multiply ") and " by " in line:
                    var, num = line[9:].split(" by ")
                    self.variables[var.strip()] = int(self.variables.get(var.strip(), 0)) * int(self.resolve_value(num))

                elif line.startswith("divide ") and " by " in line:
                    var, num = line[7:].split(" by ")
                    divisor = int(self.resolve_value(num))
                    if divisor == 0:
                        raise RuntimeError("Division by zero")
                    self.variables[var.strip()] = int(self.variables.get(var.strip(), 0)) // divisor

                elif line.startswith("calculate "):
                    parts = line.split()
                    if len(parts) != 5:
                        raise RuntimeError("calculate usage: calculate <var> <left> <op> <right>")
                    _, varname, left_t, op, right_t = parts
                    left = self.resolve_value(left_t)
                    right = self.resolve_value(right_t)
                    if op == "+":
                        res = int(left) + int(right)
                    elif op == "-":
                        res = int(left) - int(right)
                    elif op == "*":
                        res = int(left) * int(right)
                    elif op == "/":
                        if int(right) == 0:
                            raise RuntimeError("Division by zero")
                        res = int(left) // int(right)
                    else:
                        raise RuntimeError(f"Unknown operator: {op}")
                    self.variables[varname] = res

                # file & path
                elif line.startswith("create_folder "):
                    name = self.resolve_value(line[len("create_folder "):])
                    os.makedirs(name, exist_ok=True)

                elif line.startswith("ensure_path "):
                    name = self.resolve_value(line[len("ensure_path "):])
                    os.makedirs(name, exist_ok=True)

                elif line.startswith("delete_folder_recursive "):
                    name = self.resolve_value(line[len("delete_folder_recursive "):])
                    desc = f"recursively delete folder {name}"
                    if self._should_execute(desc, local_force):
                        self.delete_folder_recursive(name)

                elif line.startswith("delete_folder "):
                    name = self.resolve_value(line[len("delete_folder "):])
                    desc = f"remove folder {name}"
                    if self._should_execute(desc, local_force):
                        os.rmdir(name)

                elif line.startswith("create_file "):
                    name = self.resolve_value(line[len("create_file "):])
                    parent = os.path.dirname(name)
                    if parent:
                        os.makedirs(parent, exist_ok=True)
                    open(name, "w").close()

                elif line.startswith("delete_file "):
                    name = self.resolve_value(line[len("delete_file "):])
                    desc = f"delete file {name}"
                    if self._should_execute(desc, local_force):
                        os.remove(name)

                elif line == "list_files":
                    print(os.listdir())

                elif line.startswith("list_dir"):
                    arg = line[len("list_dir"):].strip()
                    path = self.resolve_value(arg) if arg else os.getcwd()
                    for entry in os.listdir(path):
                        print(entry)

                elif line == "pwd":
                    print(os.getcwd())

                elif line.startswith("go_to "):
                    path = self.resolve_value(line[len("go_to "):])
                    os.chdir(path)

                elif line == "go_up":
                    os.chdir("..")

                elif line.startswith("new_working "):
                    path = self.resolve_value(line[len("new_working "):])
                    os.makedirs(path, exist_ok=True)
                    os.chdir(path)

                elif line.startswith("join_path_to "):
                    parts = line.split()
                    if len(parts) < 4:
                        raise RuntimeError("join_path_to usage: join_path_to <var> \"part1\" \"part2\"")
                    varname = parts[1]
                    m = self._extract_quoted(line)
                    if len(m) < 2:
                        raise RuntimeError("join_path_to requires two quoted path parts")
                    joined = os.path.join(m[0], m[1])
                    self.variables[varname] = joined

                elif line.startswith("set_exists "):
                    parts = line.split()
                    if len(parts) < 3:
                        raise RuntimeError("set_exists usage: set_exists <var> \"path\"")
                    varname = parts[1]
                    m = self._extract_quoted(line)
                    if not m:
                        raise RuntimeError("set_exists requires a quoted path")
                    self.variables[varname] = os.path.exists(m[0])

                elif line.startswith("path_exists "):
                    path = self.resolve_value(line[len("path_exists "):])
                    print(os.path.exists(path))

                elif line.startswith("copy_file ") and " to " in line:
                    src, dst = line[len("copy_file "):].split(" to ")
                    srcv = self.resolve_value(src)
                    dstv = self.resolve_value(dst)
                    parent = os.path.dirname(dstv)
                    if parent:
                        os.makedirs(parent, exist_ok=True)
                    shutil.copy2(srcv, dstv)

                elif line.startswith("copy_pattern ") and " to " in line:
                    pat, dst = line[len("copy_pattern "):].split(" to ")
                    patv = self.resolve_value(pat)
                    dstv = self.resolve_value(dst)
                    self.copy_pattern(patv, dstv)

                elif line.startswith("xcopy ") and " to " in line:
                    src, dst = line[len("xcopy "):].split(" to ")
                    self.xcopy(self.resolve_value(src), self.resolve_value(dst), recursive=True)

                elif line.startswith("move_file ") and " to " in line:
                    src, dst = line[len("move_file "):].split(" to ")
                    srcv = self.resolve_value(src)
                    dstv = self.resolve_value(dst)
                    desc = f"move file {srcv} to {dstv}"
                    if self._should_execute(desc, local_force):
                        parent = os.path.dirname(dstv)
                        if parent:
                            os.makedirs(parent, exist_ok=True)
                        shutil.move(srcv, dstv)

                elif line.startswith("rename_file ") and " to " in line:
                    src, dst = line[len("rename_file "):].split(" to ")
                    srcv = self.resolve_value(src)
                    dstv = self.resolve_value(dst)
                    desc = f"rename file {srcv} to {dstv}"
                    if self._should_execute(desc, local_force):
                        os.rename(srcv, dstv)

                elif line.startswith("install_file ") and " to " in line:
                    src, dst = line[len("install_file "):].split(" to ")
                    srcv = self.resolve_value(src)
                    dstv = self.resolve_value(dst)
                    parent = os.path.dirname(dstv)
                    desc = f"install file {srcv} to {dstv}"
                    if self._should_execute(desc, local_force):
                        if parent:
                            os.makedirs(parent, exist_ok=True)
                        shutil.copy2(srcv, dstv)

                elif line.startswith("download_file ") and " to " in line:
                    url_part, dst_part = line[len("download_file "):].split(" to ")
                    url = self.resolve_value(url_part)
                    dst = self.resolve_value(dst_part)
                    parent = os.path.dirname(dst)
                    if parent:
                        os.makedirs(parent, exist_ok=True)
                    try:
                        urllib.request.urlretrieve(url, dst)
                    except Exception as ex:
                        raise RuntimeError(f"Download failed: {ex}")

                elif line.startswith("install_url ") and " to " in line:
                    url_part, dst_part = line[len("install_url "):].split(" to ")
                    url = self.resolve_value(url_part)
                    dst = self.resolve_value(dst_part)
                    parent = os.path.dirname(dst)
                    desc = f"download and install URL {url} to {dst}"
                    if self._should_execute(desc, local_force):
                        if parent:
                            os.makedirs(parent, exist_ok=True)
                        try:
                            fd, tmp = tempfile.mkstemp()
                            os.close(fd)
                            urllib.request.urlretrieve(url, tmp)
                            shutil.copy2(tmp, dst)
                            os.remove(tmp)
                        except Exception as ex:
                            raise RuntimeError(f"install_url failed: {ex}")

                # file content
                elif line.startswith("write_text ") and " to " in line:
                    text, file = line[len("write_text "):].split(" to ")
                    with open(self.resolve_value(file), "w", encoding="utf-8") as f:
                        f.write(str(self.resolve_value(text)))

                elif line.startswith("append_text ") and " to " in line:
                    text, file = line[len("append_text "):].split(" to ")
                    with open(self.resolve_value(file), "a", encoding="utf-8") as f:
                        f.write(str(self.resolve_value(text)))

                elif line.startswith("read_file "):
                    file = self.resolve_value(line[len("read_file "):])
                    with open(file, "r", encoding="utf-8") as f:
                        print(f.read())

                # system
                elif line.startswith("run_command "):
                    cmd = self.resolve_value(line[len("run_command "):])
                    subprocess.run(cmd, shell=True)

                elif line.startswith("start_program "):
                    cmd = self.resolve_value(line[len("start_program "):])
                    self.start_program(cmd)

                elif line.startswith("ping_host "):
                    parts = line.split()
                    if len(parts) == 2:
                        host = self.resolve_value(parts[1])
                        ok = self.ping_host(host, 1)
                    elif len(parts) == 3:
                        host = self.resolve_value(parts[1])
                        count = int(self.resolve_value(parts[2]))
                        ok = self.ping_host(host, count)
                    else:
                        raise RuntimeError("ping_host usage: ping_host \"host\" [count]")
                    print(str(ok))

                elif line.startswith("wait ") and line.endswith(" seconds"):
                    seconds = int(line.split()[1])
                    time.sleep(seconds)

                # tasks / control flow
                elif line.startswith("if "):
                    condition = line[3:]
                    result = self.evaluate_condition(condition)
                    next_i = self.execute_block(lines, i + 1, indent + 4, filename) if result else self.skip_block(lines, i + 1, indent + 4)
                    if next_i < len(lines) and lines[next_i].strip() == "else":
                        if result:
                            next_i = self.skip_block(lines, next_i + 1, indent + 4)
                        else:
                            next_i = self.execute_block(lines, next_i + 1, indent + 4, filename)
                    i = next_i
                    continue

                elif line.startswith("repeat ") and line.endswith(" times"):
                    count_token = line.split()[1]
                    count = int(self.resolve_value(count_token))
                    block_start = i + 1
                    block_end = self.skip_block(lines, block_start, indent + 4)
                    for _ in range(count):
                        self.execute_block(lines, block_start, indent + 4, filename)
                    i = block_end
                    continue

                elif line.startswith("define task "):
                    rest = line[len("define task "):].strip()
                    params = []
                    if " with " in rest:
                        name_part, params_part = rest.split(" with ", 1)
                        name = name_part.strip()
                        params = params_part.split()
                    else:
                        name = rest
                    block_start = i + 1
                    block_end = self.skip_block(lines, block_start, indent + 4)
                    self.tasks[name] = (params, lines[block_start:block_end])
                    i = block_end
                    continue

                elif line.startswith("run task "):
                    rest = line[len("run task "):].strip()
                    args = []
                    if " with " in rest:
                        name_part, args_part = rest.split(" with ", 1)
                        name = name_part.strip()
                        args = self._extract_quoted(args_part)
                    else:
                        name = rest
                    if name not in self.tasks:
                        raise RuntimeError(f"Task not defined: {name}")
                    param_list, task_lines = self.tasks[name]
                    old_vars = dict(self.variables)
                    try:
                        for idx, pname in enumerate(param_list):
                            if idx < len(args):
                                self.variables[pname] = args[idx]
                            else:
                                self.variables[pname] = None
                        task_filename = f"{filename}::task::{name}"
                        self.execute_block(task_lines, 0, 0, task_filename)
                    finally:
                        self.variables = old_vars

                else:
                    raise RuntimeError(f"Unknown command: {line}")

            except Exception as e:
                raise RuntimeError(f"{filename}:{lineno}: Error processing line '{line}': {e}")

            i += 1
        return i

    # -------------------------
    # Block helpers
    # -------------------------
    def skip_block(self, lines, start_index, base_indent):
        i = start_index
        while i < len(lines):
            raw = lines[i]
            if raw.strip() == "":
                i += 1
                continue
            indent = self.get_indent_level(raw)
            if indent < base_indent:
                return i
            i += 1
        return i

    # -------------------------
    # Condition evaluation
    # -------------------------
    def evaluate_condition(self, cond):
        parts = cond.split()
        if len(parts) == 2 and parts[1] == 'exists':
            left = self.resolve_value(parts[0])
            return os.path.exists(left)
        if len(parts) < 3:
            raise RuntimeError("Invalid condition")
        left = self.resolve_value(parts[0])
        op = parts[1]
        right = self.resolve_value(" ".join(parts[2:]))
        if op == "is":
            return left == right
        if op == "is_not":
            return left != right
        if op == "greater_than":
            return left > right
        if op == "less_than":
            return left < right
        raise RuntimeError(f"Unknown comparison operator: {op}")


# -------------------------
# Entry point
# -------------------------
if __name__ == "__main__":
    parser = argparse.ArgumentParser(prog="doscript", description="DoScript interpreter")
    parser.add_argument('file', help='.do script to run')
    parser.add_argument('--dry-run', action='store_true', help='preview actions without executing')
    parser.add_argument('--force', action='store_true', help='treat destructive actions as forced')
    args = parser.parse_args()

    if not os.path.exists(args.file):
        print(f"File not found: {args.file}")
        sys.exit(1)

    runtime = DoScriptRuntime()
    runtime.dry_run = args.dry_run
    runtime.force = args.force
    # also set variables visible to scripts
    runtime.variables['dry_run'] = args.dry_run
    runtime.variables['force'] = args.force

    try:
        runtime.run_file(args.file)
    except Exception as e:
        print(f"DoScript Error: {e}")
        sys.exit(1)
