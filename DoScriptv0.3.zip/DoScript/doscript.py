#!/usr/bin/env python3
"""
DoScript Interpreter v2.0
A simple automation DSL interpreter
"""

import os
import sys
import shutil
import subprocess
import urllib.request
import urllib.error
import re
import ast
import operator
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple


class DoScriptError(Exception):
    """Base exception for DoScript errors"""
    pass


class NetworkError(DoScriptError):
    """Network operation errors"""
    pass


class FileError(DoScriptError):
    """File operation errors"""
    pass


class ProcessError(DoScriptError):
    """Process execution errors"""
    pass


class DoScriptInterpreter:
    def __init__(self):
        self.path_stack = []
        self.global_vars = {}
        self.declared_globals = set()
        self.functions = {}
        self.macros = {}
        self.local_scope = None  # Stack of local variable dicts
        
    def resolve_path(self, path: str) -> str:
        """Resolve path using path stack"""
        if os.path.isabs(path):
            return path
        if self.path_stack:
            return os.path.join(self.path_stack[-1], path)
        return path
    
    def interpolate_string(self, s: str) -> str:
        """Interpolate variables in single-quoted strings"""
        def replace_var(match):
            var_name = match.group(1)
            value = self.get_variable(var_name)
            return str(value) if value is not None else ""
        
        # Replace {var} but not \{var\}
        # First, handle escaped braces
        s = s.replace(r'\{', '\x00').replace(r'\}', '\x01')
        # Interpolate variables
        s = re.sub(r'\{(\w+)\}', replace_var, s)
        # Restore escaped braces
        s = s.replace('\x00', '{').replace('\x01', '}')
        return s
    
    def interpolate_if_needed(self, s: str) -> str:
        """Interpolate variables if string contains {var} patterns"""
        if '{' in s and '}' in s:
            return self.interpolate_string(s)
        return s
    
    def get_variable(self, name: str) -> Any:
        """Get variable value (check local scope first, then global)"""
        if self.local_scope is not None and name in self.local_scope:
            return self.local_scope[name]
        if name in self.global_vars:
            return self.global_vars[name]
        raise DoScriptError(f"Variable '{name}' is not defined")
    
    def set_variable(self, name: str, value: Any):
        """Set variable value"""
        # Check if in local scope
        if self.local_scope is not None and name in self.local_scope:
            self.local_scope[name] = value
        # Check if declared as global
        elif name in self.declared_globals:
            self.global_vars[name] = value
        else:
            raise DoScriptError(f"Variable '{name}' used before declaration")
    
    def evaluate_expression(self, expr: str) -> Any:
        """Safely evaluate expressions"""
        expr = expr.strip()
        
        # Handle string literals
        if (expr.startswith('"') and expr.endswith('"')):
            return expr[1:-1]
        if (expr.startswith("'") and expr.endswith("'")):
            # Interpolate single-quoted strings
            return self.interpolate_string(expr[1:-1])
        
        # Handle booleans
        if expr == 'true':
            return True
        if expr == 'false':
            return False
        
        # Handle numeric literals (integer or float)
        try:
            if '.' in expr:
                return float(expr)
            else:
                return int(expr)
        except ValueError:
            pass
        
        # Handle function calls
        func_call_match = re.match(r'(\w+)\((.*?)\)$', expr)
        if func_call_match:
            func_name = func_call_match.group(1)
            args_str = func_call_match.group(2).strip()
            
            # Built-in: exists predicate
            if func_name == 'exists':
                if args_str:
                    path_arg = self.evaluate_expression(args_str)
                    return os.path.exists(self.resolve_path(str(path_arg)))
                return False
            
            # Built-in: date function
            if func_name == 'date':
                from datetime import datetime
                return datetime.now().strftime('%Y-%m-%d')
            
            # Built-in: time function
            if func_name == 'time':
                from datetime import datetime
                return datetime.now().strftime('%H:%M:%S')
            
            # Built-in: datetime function
            if func_name == 'datetime':
                from datetime import datetime
                return datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            
            # Built-in string functions
            if func_name == 'substring':
                args = [self.evaluate_expression(a.strip()) for a in args_str.split(',')]
                if len(args) >= 3:
                    text = str(args[0])
                    start = int(args[1])
                    length = int(args[2])
                    return text[start:start+length]
                elif len(args) == 2:
                    text = str(args[0])
                    start = int(args[1])
                    return text[start:]
                return ""
            
            if func_name == 'replace':
                args = [self.evaluate_expression(a.strip()) for a in args_str.split(',')]
                if len(args) >= 3:
                    text = str(args[0])
                    old = str(args[1])
                    new = str(args[2])
                    return text.replace(old, new)
                return ""
            
            if func_name == 'length':
                if args_str:
                    text = str(self.evaluate_expression(args_str))
                    return len(text)
                return 0
            
            if func_name == 'uppercase':
                if args_str:
                    text = str(self.evaluate_expression(args_str))
                    return text.upper()
                return ""
            
            if func_name == 'lowercase':
                if args_str:
                    text = str(self.evaluate_expression(args_str))
                    return text.lower()
                return ""
            
            if func_name == 'trim':
                if args_str:
                    text = str(self.evaluate_expression(args_str))
                    return text.strip()
                return ""
            
            if func_name == 'contains':
                args = [self.evaluate_expression(a.strip()) for a in args_str.split(',')]
                if len(args) >= 2:
                    text = str(args[0])
                    search = str(args[1])
                    return search in text
                return False
            
            if func_name == 'startswith':
                args = [self.evaluate_expression(a.strip()) for a in args_str.split(',')]
                if len(args) >= 2:
                    text = str(args[0])
                    prefix = str(args[1])
                    return text.startswith(prefix)
                return False
            
            if func_name == 'endswith':
                args = [self.evaluate_expression(a.strip()) for a in args_str.split(',')]
                if len(args) >= 2:
                    text = str(args[0])
                    suffix = str(args[1])
                    return text.endswith(suffix)
                return False
            
            if func_name == 'split':
                args = [self.evaluate_expression(a.strip()) for a in args_str.split(',')]
                if len(args) >= 2:
                    text = str(args[0])
                    delimiter = str(args[1])
                    # Return a simple list representation (will be converted to string)
                    parts = text.split(delimiter)
                    # For now, return as a list (Python list)
                    return parts
                elif len(args) == 1:
                    text = str(args[0])
                    # Split on whitespace
                    return text.split()
                return []
            
            if func_name == 'read_file':
                if args_str:
                    file_path = str(self.evaluate_expression(args_str))
                    file_resolved = self.resolve_path(file_path)
                    try:
                        with open(file_resolved, 'r') as f:
                            return f.read()
                    except Exception as e:
                        raise FileError(f"Failed to read file '{file_path}': {e}")
                return ""
            
            # User-defined function
            if func_name in self.functions:
                args = []
                if args_str:
                    # Parse arguments (simple comma split)
                    args = [self.evaluate_expression(a.strip()) for a in args_str.split(',')]
                return self.call_function(func_name, args)
            
            raise DoScriptError(f"Unknown function: {func_name}")
        
        # Handle 'exists' without parentheses
        exists_match = re.match(r'exists\s+"([^"]+)"', expr)
        if exists_match:
            path = exists_match.group(1)
            return os.path.exists(self.resolve_path(path))
        
        # Handle variable references (simple identifier)
        if re.match(r'^\w+$', expr):
            return self.get_variable(expr)
        
        # Handle operators and complex expressions
        try:
            # Create a safe namespace for evaluation
            namespace = {
                'true': True,
                'false': False,
                '__builtins__': {}
            }
            
            # Add all variables to namespace
            if self.local_scope:
                namespace.update(self.local_scope)
            namespace.update(self.global_vars)
            
            # Parse and evaluate
            tree = ast.parse(expr, mode='eval')
            result = self._eval_node(tree.body, namespace)
            return result
            
        except Exception as e:
            raise DoScriptError(f"Failed to evaluate expression '{expr}': {e}")
    
    def _eval_node(self, node, namespace):
        """Safely evaluate AST node"""
        if isinstance(node, ast.Constant):
            return node.value
        elif isinstance(node, ast.Name):
            if node.id in namespace:
                return namespace[node.id]
            raise DoScriptError(f"Variable '{node.id}' not found")
        elif isinstance(node, ast.BinOp):
            left = self._eval_node(node.left, namespace)
            right = self._eval_node(node.right, namespace)
            ops = {
                ast.Add: operator.add,
                ast.Sub: operator.sub,
                ast.Mult: operator.mul,
                ast.Div: operator.truediv,
                ast.Mod: operator.mod,
            }
            if type(node.op) in ops:
                return ops[type(node.op)](left, right)
        elif isinstance(node, ast.UnaryOp):
            operand = self._eval_node(node.operand, namespace)
            if isinstance(node.op, ast.Not):
                return not operand
            elif isinstance(node.op, ast.USub):
                return -operand
        elif isinstance(node, ast.Compare):
            left = self._eval_node(node.left, namespace)
            for op, comparator in zip(node.ops, node.comparators):
                right = self._eval_node(comparator, namespace)
                if isinstance(op, ast.Eq):
                    if not (left == right):
                        return False
                elif isinstance(op, ast.NotEq):
                    if not (left != right):
                        return False
                elif isinstance(op, ast.Lt):
                    if not (left < right):
                        return False
                elif isinstance(op, ast.Gt):
                    if not (left > right):
                        return False
                elif isinstance(op, ast.LtE):
                    if not (left <= right):
                        return False
                elif isinstance(op, ast.GtE):
                    if not (left >= right):
                        return False
                left = right
            return True
        elif isinstance(node, ast.BoolOp):
            if isinstance(node.op, ast.And):
                result = True
                for value in node.values:
                    result = result and self._eval_node(value, namespace)
                    if not result:
                        return False
                return result
            elif isinstance(node.op, ast.Or):
                result = False
                for value in node.values:
                    result = result or self._eval_node(value, namespace)
                    if result:
                        return True
                return result
        
        raise DoScriptError(f"Unsupported expression type: {type(node).__name__}")
    
    def call_function(self, name: str, args: List[Any]) -> Any:
        """Call a user-defined function"""
        if name not in self.functions:
            raise DoScriptError(f"Function '{name}' not defined")
        
        func = self.functions[name]
        params = func['params']
        body = func['body']
        
        # Create local scope
        old_local_scope = self.local_scope
        self.local_scope = {}
        
        # Bind parameters to arguments
        for i, param in enumerate(params):
            self.local_scope[param] = args[i] if i < len(args) else None
        
        # Execute function body
        return_value = None
        try:
            for stmt in body:
                result = self.execute_statement(stmt)
                if result is not None and result[0] == 'return':
                    return_value = result[1]
                    break
        finally:
            # Restore previous scope
            self.local_scope = old_local_scope
        
        return return_value
    
    def parse_script(self, filename: str) -> List[str]:
        """Parse script file into statements"""
        with open(filename, 'r') as f:
            lines = f.readlines()
        
        # Remove comments and blank lines
        statements = []
        current_line = ""
        
        for line in lines:
            # Remove comments
            line = re.sub(r'#.*$', '', line)
            line = re.sub(r'//.*$', '', line)
            line = line.strip()
            
            if line:
                current_line += " " + line if current_line else line
                statements.append(current_line)
                current_line = ""
        
        return statements
    
    def execute_statement(self, stmt: str) -> Optional[Tuple[str, Any]]:
        """Execute a single statement"""
        stmt = stmt.strip()
        
        if not stmt:
            return None
        
        # PATH operations
        if stmt.startswith('path add '):
            path = self.extract_string(stmt[9:])
            self.path_stack.append(path)
            return None
        
        if stmt.startswith('path remove '):
            path = self.extract_string(stmt[12:])
            if path in self.path_stack:
                self.path_stack.remove(path)
            return None
        
        if stmt == 'path list':
            for p in self.path_stack:
                print(p)
            return None
        
        # MAKE operations
        if stmt.startswith('make folder '):
            path = self.extract_string(stmt[12:])
            resolved = self.resolve_path(path)
            try:
                os.makedirs(resolved, exist_ok=True)
            except Exception as e:
                raise FileError(f"Failed to create folder '{path}': {e}")
            return None
        
        if stmt.startswith('make file '):
            # Match: make file "path" with "content" or make file "path" with 'content'
            match = re.match(r'make file "([^"]+)" with (.+)$', stmt)
            if match:
                path = match.group(1)
                content_expr = match.group(2).strip()
                
                # Handle both single and double quoted content
                if content_expr.startswith('"'):
                    # Find the closing quote
                    end_idx = content_expr.rfind('"')
                    if end_idx > 0:
                        content = content_expr[1:end_idx]
                    else:
                        content = content_expr[1:]
                    # Decode escape sequences in double-quoted strings
                    content = content.encode().decode('unicode_escape')
                elif content_expr.startswith("'"):
                    # Find the closing quote
                    end_idx = content_expr.rfind("'")
                    if end_idx > 0:
                        content = self.interpolate_string(content_expr[1:end_idx])
                    else:
                        content = self.interpolate_string(content_expr[1:])
                else:
                    content = str(self.evaluate_expression(content_expr))
                
                resolved = self.resolve_path(path)
                try:
                    os.makedirs(os.path.dirname(resolved), exist_ok=True)
                    with open(resolved, 'w') as f:
                        f.write(content)
                except Exception as e:
                    raise FileError(f"Failed to create file '{path}': {e}")
            return None
        
        # COPY operation
        if ' to ' in stmt and stmt.startswith('copy '):
            match = re.match(r'copy "([^"]+)" to "([^"]+)"$', stmt)
            if match:
                src, dst = match.groups()
                src_resolved = self.resolve_path(src)
                dst_resolved = self.resolve_path(dst)
                try:
                    shutil.copy2(src_resolved, dst_resolved)
                except Exception as e:
                    raise FileError(f"Failed to copy '{src}' to '{dst}': {e}")
            return None
        
        # MOVE operation
        if ' to ' in stmt and stmt.startswith('move '):
            match = re.match(r'move "([^"]+)" to "([^"]+)"$', stmt)
            if match:
                src, dst = match.groups()
                src_resolved = self.resolve_path(src)
                dst_resolved = self.resolve_path(dst)
                try:
                    shutil.move(src_resolved, dst_resolved)
                except Exception as e:
                    raise FileError(f"Failed to move '{src}' to '{dst}': {e}")
            return None
        
        # DELETE operation
        if stmt.startswith('delete '):
            path_expr = stmt[7:].strip()
            # Could be a quoted string or a variable
            if path_expr.startswith('"') or path_expr.startswith("'"):
                path = self.extract_string(path_expr)
            else:
                # It's a variable or expression
                path = str(self.evaluate_expression(path_expr))
            
            resolved = self.resolve_path(path)
            try:
                if os.path.isdir(resolved):
                    shutil.rmtree(resolved)
                else:
                    os.remove(resolved)
            except Exception as e:
                raise FileError(f"Failed to delete '{path}': {e}")
            return None
        
        # DOWNLOAD operation
        if stmt.startswith('download ') and ' to ' in stmt:
            match = re.match(r'download "([^"]+)" to "([^"]+)"$', stmt)
            if match:
                url, path = match.groups()
                resolved = self.resolve_path(path)
                try:
                    os.makedirs(os.path.dirname(resolved), exist_ok=True)
                    urllib.request.urlretrieve(url, resolved)
                except Exception as e:
                    raise NetworkError(f"Failed to download '{url}': {e}")
            return None
        
        # UPLOAD operation
        if stmt.startswith('upload ') and ' to ' in stmt:
            match = re.match(r'upload "([^"]+)" to "([^"]+)"$', stmt)
            if match:
                path, url = match.groups()
                resolved = self.resolve_path(path)
                try:
                    with open(resolved, 'rb') as f:
                        data = f.read()
                    req = urllib.request.Request(url, data=data, method='POST')
                    urllib.request.urlopen(req)
                except Exception as e:
                    raise NetworkError(f"Failed to upload '{path}': {e}")
            return None
        
        # PING operation
        if stmt.startswith('ping '):
            host = self.extract_string(stmt[5:])
            try:
                if sys.platform == 'win32':
                    subprocess.run(['ping', '-n', '1', host], check=True)
                else:
                    subprocess.run(['ping', '-c', '1', host], check=True)
            except Exception as e:
                raise NetworkError(f"Failed to ping '{host}': {e}")
            return None
        
        # RUN operation
        if stmt.startswith('run '):
            name = self.extract_string(stmt[4:])
            
            # Check if it's a macro
            if name in self.macros:
                for macro_stmt in self.macros[name]:
                    self.execute_statement(macro_stmt)
                return None
            else:
                # Run as external command and return exit code
                try:
                    result = subprocess.run(name, shell=True, capture_output=False)
                    return ('exit_code', result.returncode)
                except Exception as e:
                    raise ProcessError(f"Failed to run '{name}': {e}")
            return None
        
        # CAPTURE operation (run command and capture output)
        if stmt.startswith('capture '):
            name = self.extract_string(stmt[8:])
            
            try:
                result = subprocess.run(name, shell=True, capture_output=True, text=True)
                # Return the stdout as the result
                return ('capture_output', result.stdout.strip())
            except Exception as e:
                raise ProcessError(f"Failed to capture '{name}': {e}")
            return None
        
        # EXIT statement
        if stmt.startswith('exit'):
            if stmt == 'exit':
                sys.exit(0)
            else:
                # exit N
                code_expr = stmt[4:].strip()
                code = int(self.evaluate_expression(code_expr))
                sys.exit(code)
            return None
        
        # BREAK statement
        if stmt == 'break':
            return ('break', None)
        
        # CONTINUE statement
        if stmt == 'continue':
            return ('continue', None)
        
        # KILL operation
        if stmt.startswith('kill '):
            proc_name = self.extract_string(stmt[5:])
            try:
                if sys.platform == 'win32':
                    subprocess.run(['taskkill', '/F', '/IM', proc_name], check=True)
                else:
                    subprocess.run(['pkill', proc_name], check=True)
            except Exception as e:
                raise ProcessError(f"Failed to kill '{proc_name}': {e}")
            return None
        
        # SAY operation
        if stmt.startswith('say '):
            expr = stmt[4:].strip()
            value = self.evaluate_expression(expr)
            print(value)
            return None
        
        # ASK operation (user input)
        if stmt.startswith('ask '):
            match = re.match(r'ask (\w+) (.+)$', stmt)
            if match:
                var_name = match.group(1)
                prompt_expr = match.group(2)
                prompt = str(self.evaluate_expression(prompt_expr))
                
                # Get user input
                user_input = input(prompt + " ")
                
                # Store in variable
                self.set_variable(var_name, user_input)
            return None
        
        # PAUSE operation (wait for keypress)
        if stmt == 'pause':
            input("Press Enter to continue...")
            return None
        
        # WAIT operation (sleep N seconds)
        if stmt.startswith('wait '):
            seconds_expr = stmt[5:].strip()
            seconds = self.evaluate_expression(seconds_expr)
            import time
            time.sleep(float(seconds))
            return None
        
        # GLOBAL_VARIABLE declaration
        if stmt.startswith('global_variable = '):
            var_names = stmt[18:].split(',')
            for var_name in var_names:
                var_name = var_name.strip()
                self.declared_globals.add(var_name)
                if var_name not in self.global_vars:
                    self.global_vars[var_name] = None
            return None
        
        # LOCAL_VARIABLE declaration (only valid inside functions)
        if stmt.startswith('local_variable = '):
            if self.local_scope is None:
                raise DoScriptError("local_variable can only be used inside functions")
            var_names = stmt[17:].split(',')
            for var_name in var_names:
                var_name = var_name.strip()
                if var_name not in self.local_scope:
                    self.local_scope[var_name] = None
            return None
        
        # RETURN statement
        if stmt.startswith('return'):
            if stmt == 'return':
                return ('return', None)
            else:
                expr = stmt[6:].strip()
                value = self.evaluate_expression(expr)
                return ('return', value)
        
        # Variable assignment
        if '=' in stmt and not stmt.startswith(('if ', 'repeat ', 'loop ')):
            match = re.match(r'(\w+)\s*=\s*(.+)$', stmt)
            if match:
                var_name, expr = match.groups()
                
                # Check if it's a run command (to capture exit code)
                if expr.strip().startswith('run '):
                    # Execute the run command and get exit code
                    result = self.execute_statement(expr.strip())
                    if result and result[0] == 'exit_code':
                        self.set_variable(var_name, result[1])
                    else:
                        self.set_variable(var_name, 0)
                # Check if it's a capture command (to capture output)
                elif expr.strip().startswith('capture '):
                    # Execute the capture command and get output
                    result = self.execute_statement(expr.strip())
                    if result and result[0] == 'capture_output':
                        self.set_variable(var_name, result[1])
                    else:
                        self.set_variable(var_name, "")
                else:
                    value = self.evaluate_expression(expr.strip())
                    self.set_variable(var_name, value)
                return None
        
        return None
    
    def extract_string(self, s: str) -> str:
        """Extract string from quotes"""
        s = s.strip()
        if s.startswith('"') and s.endswith('"'):
            return s[1:-1]
        if s.startswith("'") and s.endswith("'"):
            return self.interpolate_string(s[1:-1])
        return s
    
    def execute_block(self, lines: List[str], start_idx: int, end_keyword: str) -> Tuple[int, List[str]]:
        """Extract a block of statements until end_keyword"""
        block = []
        i = start_idx
        depth = 1
        
        # Determine start keyword
        start_keywords = {
            'end_function': 'function',
            'end_loop': 'loop',
            'end_repeat': 'repeat',
            'end_if': 'if',
            'end_try': 'try',
            'end_command': 'make a command',
            'end_for': 'for_each',
        }
        
        start_keyword = start_keywords.get(end_keyword, '')
        
        while i < len(lines):
            line = lines[i].strip()
            
            # Check for nested blocks
            if start_keyword and line.startswith(start_keyword):
                depth += 1
            elif line == end_keyword or line.startswith(end_keyword + ' '):
                depth -= 1
                if depth == 0:
                    return i, block
            
            block.append(lines[i])
            i += 1
        
        raise DoScriptError(f"Missing {end_keyword}")
    
    def run(self, filename: str):
        """Run a DoScript file"""
        lines = self.parse_script(filename)
        self.execute_lines(lines)
    
    def execute_lines(self, lines: List[str], start_idx: int = 0, end_idx: Optional[int] = None):
        """Execute a list of statement lines"""
        if end_idx is None:
            end_idx = len(lines)
        
        i = start_idx
        while i < end_idx:
            stmt = lines[i].strip()
            
            # FUNCTION definition
            if stmt.startswith('function '):
                match = re.match(r'function (\w+)\s*(.*)', stmt)
                if match:
                    func_name = match.group(1)
                    params_str = match.group(2).strip()
                    params = [p.strip() for p in params_str.split()] if params_str else []
                    
                    # Extract function body
                    end_idx_func, body = self.execute_block(lines, i + 1, 'end_function')
                    
                    self.functions[func_name] = {
                        'params': params,
                        'body': body
                    }
                    
                    i = end_idx_func + 1
                    continue
            
            # MACRO definition
            if stmt.startswith('make a command '):
                macro_name = stmt[15:].strip()
                end_idx_macro, body = self.execute_block(lines, i + 1, 'end_command')
                self.macros[macro_name] = body
                i = end_idx_macro + 1
                continue
            
            # IF statement
            if stmt.startswith('if '):
                condition_expr = stmt[3:].strip()
                condition = self.evaluate_expression(condition_expr)
                
                # Find else and end_if
                depth = 1
                else_idx = None
                end_if_idx = None
                j = i + 1
                
                while j < len(lines):
                    line = lines[j].strip()
                    if line.startswith('if '):
                        depth += 1
                    elif line == 'else' and depth == 1:
                        else_idx = j
                    elif line == 'end_if':
                        depth -= 1
                        if depth == 0:
                            end_if_idx = j
                            break
                    j += 1
                
                if end_if_idx is None:
                    raise DoScriptError("Missing end_if")
                
                if condition:
                    # Execute if block
                    if_end = else_idx if else_idx else end_if_idx
                    result = self.execute_lines(lines, i + 1, if_end)
                    if result and result[0] in ('return', 'break', 'continue'):
                        return result
                else:
                    # Execute else block if present
                    if else_idx:
                        result = self.execute_lines(lines, else_idx + 1, end_if_idx)
                        if result and result[0] in ('return', 'break', 'continue'):
                            return result
                
                i = end_if_idx + 1
                continue
            
            # REPEAT loop
            if stmt.startswith('repeat '):
                count_expr = stmt[7:].strip()
                count = int(self.evaluate_expression(count_expr))
                
                end_idx_repeat, body = self.execute_block(lines, i + 1, 'end_repeat')
                
                for _ in range(count):
                    result = self.execute_lines(body, 0, len(body))
                    if result and result[0] == 'break':
                        break
                    if result and result[0] == 'continue':
                        continue
                
                i = end_idx_repeat + 1
                continue
            
            # LOOP statement
            if stmt.startswith('loop '):
                loop_expr = stmt[5:].strip()
                
                if loop_expr == 'forever':
                    end_idx_loop, body = self.execute_block(lines, i + 1, 'end_loop')
                    
                    while True:
                        try:
                            result = self.execute_lines(body, 0, len(body))
                            if result and result[0] == 'break':
                                break
                        except KeyboardInterrupt:
                            break
                    
                    i = end_idx_loop + 1
                    continue
                else:
                    # Loop N times
                    count = int(self.evaluate_expression(loop_expr))
                    end_idx_loop, body = self.execute_block(lines, i + 1, 'end_loop')
                    
                    for _ in range(count):
                        result = self.execute_lines(body, 0, len(body))
                        if result and result[0] == 'break':
                            break
                        if result and result[0] == 'continue':
                            continue
                    
                    i = end_idx_loop + 1
                    continue
            
            # TRY/CATCH statement
            if stmt == 'try':
                # Find catch blocks and end_try
                catch_blocks = []
                depth = 1
                j = i + 1
                try_body_end = None
                
                while j < len(lines):
                    line = lines[j].strip()
                    
                    if line == 'try':
                        depth += 1
                    elif line.startswith('catch'):
                        if depth == 1:
                            if try_body_end is None:
                                try_body_end = j
                            
                            # Parse catch type
                            error_type = None
                            if line != 'catch':
                                error_type = line[6:].strip()
                            
                            # Find end of this catch block
                            k = j + 1
                            while k < len(lines):
                                next_line = lines[k].strip()
                                if next_line == 'end_try' or next_line.startswith('catch'):
                                    break
                                k += 1
                            
                            catch_blocks.append({
                                'type': error_type,
                                'start': j + 1,
                                'end': k
                            })
                            j = k - 1
                    elif line == 'end_try':
                        depth -= 1
                        if depth == 0:
                            if try_body_end is None:
                                try_body_end = j
                            
                            # Execute try block
                            try:
                                self.execute_lines(lines, i + 1, try_body_end)
                            except DoScriptError as e:
                                # Find matching catch block
                                error_class_name = type(e).__name__
                                handled = False
                                
                                for catch_block in catch_blocks:
                                    if catch_block['type'] is None or catch_block['type'] == error_class_name:
                                        self.execute_lines(lines, catch_block['start'], catch_block['end'])
                                        handled = True
                                        break
                                
                                if not handled:
                                    raise
                            
                            i = j + 1
                            break
                    j += 1
                
                continue
            
            # FOR_EACH statement - iterate files
            if stmt.startswith('for_each ') and ' in ' in stmt:
                # Parse: for_each varname in "pattern" or for_each varname in "item1", "item2", ...
                match = re.match(r'for_each (\w+) in (.+)$', stmt)
                if match:
                    var_name = match.group(1)
                    in_expr = match.group(2).strip()
                    
                    # Check if it's a file pattern (single quoted string) or list of items (comma-separated)
                    if ',' in in_expr:
                        # List of items: "apple", "banana", "cherry"
                        items = []
                        for item_expr in in_expr.split(','):
                            item_value = self.evaluate_expression(item_expr.strip())
                            items.append(item_value)
                        
                        # Find end_for
                        end_idx_for, body = self.execute_block(lines, i + 1, 'end_for')
                        
                        # Declare the loop variable in global scope if not already declared
                        if var_name not in self.declared_globals:
                            self.declared_globals.add(var_name)
                            self.global_vars[var_name] = None
                        
                        # Execute body for each item
                        for item in items:
                            self.set_variable(var_name, item)
                            result = self.execute_lines(body, 0, len(body))
                            if result and result[0] == 'break':
                                break
                            if result and result[0] == 'continue':
                                continue
                        
                        i = end_idx_for + 1
                        continue
                    else:
                        # File pattern: "*.txt"
                        pattern = self.evaluate_expression(in_expr)
                        pattern_resolved = self.resolve_path(str(pattern))
                        
                        # Get matching files
                        import glob
                        files = glob.glob(pattern_resolved)
                        
                        # Find end_for
                        end_idx_for, body = self.execute_block(lines, i + 1, 'end_for')
                        
                        # Declare the loop variable in global scope if not already declared
                        if var_name not in self.declared_globals:
                            self.declared_globals.add(var_name)
                            self.global_vars[var_name] = None
                        
                        # Execute body for each file
                        for file_path in files:
                            # Store just the filename, not full path (or full path if needed)
                            filename = os.path.basename(file_path)
                            self.set_variable(var_name, filename)
                            result = self.execute_lines(body, 0, len(body))
                            if result and result[0] == 'break':
                                break
                            if result and result[0] == 'continue':
                                continue
                        
                        i = end_idx_for + 1
                        continue
            
            # FOR_EACH_LINE statement - read file line by line
            if stmt.startswith('for_each_line ') and ' in ' in stmt:
                # Parse: for_each_line varname in "filename"
                match = re.match(r'for_each_line (\w+) in (.+)$', stmt)
                if match:
                    var_name = match.group(1)
                    file_expr = match.group(2).strip()
                    
                    # Evaluate the file expression (could contain variables or interpolation)
                    file_path_value = self.evaluate_expression(file_expr)
                    
                    # Additionally interpolate if it has {var} patterns
                    file_path_str = str(file_path_value)
                    file_path_interpolated = self.interpolate_if_needed(file_path_str)
                    
                    file_resolved = self.resolve_path(file_path_interpolated)
                    
                    # Find end_for
                    end_idx_for, body = self.execute_block(lines, i + 1, 'end_for')
                    
                    # Declare the loop variable in global scope if not already declared
                    if var_name not in self.declared_globals:
                        self.declared_globals.add(var_name)
                        self.global_vars[var_name] = None
                    
                    # Read file and execute body for each line
                    try:
                        with open(file_resolved, 'r') as f:
                            for line in f:
                                line = line.rstrip('\n\r')  # Remove newline
                                self.set_variable(var_name, line)
                                result = self.execute_lines(body, 0, len(body))
                                if result and result[0] == 'break':
                                    break
                                if result and result[0] == 'continue':
                                    continue
                    except Exception as e:
                        raise FileError(f"Failed to read file '{file_path_interpolated}': {e}")
                    
                    i = end_idx_for + 1
                    continue
            
            # Regular statement
            result = self.execute_statement(stmt)
            if result is not None:
                if result[0] in ('return', 'break', 'continue'):
                    return result
            
            i += 1


def main():
    if len(sys.argv) < 2:
        print("Usage: python doscript.py <script.do>")
        sys.exit(1)
    
    script_file = sys.argv[1]
    
    if not os.path.exists(script_file):
        print(f"Error: File '{script_file}' not found")
        sys.exit(1)
    
    interpreter = DoScriptInterpreter()
    
    try:
        interpreter.run(script_file)
    except DoScriptError as e:
        print(f"DoScript Error: {e}", file=sys.stderr)
        sys.exit(1)
    except KeyboardInterrupt:
        print("\nScript interrupted by user")
        sys.exit(0)
    except Exception as e:
        print(f"Unexpected error: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == '__main__':
    main()
